var classScoreSubmit =
[
    [ "Start", "classScoreSubmit.html#af0a6e59adba1ff8a2df8c95a55fe0697", null ],
    [ "Update", "classScoreSubmit.html#ade4d0cc95fd6c77e0675b22697624ec0", null ],
    [ "Win", "classScoreSubmit.html#ae8cd5fdf8c774668bd4d4cf0a005e2fc", null ],
    [ "_inputField", "classScoreSubmit.html#a9d0dfa0e26d6c90d482cae0add0a5f5b", null ]
];