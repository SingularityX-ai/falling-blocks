var IUpdatable_8cs =
[
    [ "gamerunner.IUpdatable", "interfacegamerunner_1_1IUpdatable.html", "interfacegamerunner_1_1IUpdatable" ]
];