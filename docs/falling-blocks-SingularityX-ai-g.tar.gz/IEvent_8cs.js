var IEvent_8cs =
[
    [ "game.logic.EventQueue.IEvent", "interfacegame_1_1logic_1_1EventQueue_1_1IEvent.html", "interfacegame_1_1logic_1_1EventQueue_1_1IEvent" ]
];