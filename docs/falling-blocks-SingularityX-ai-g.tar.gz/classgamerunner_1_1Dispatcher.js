var classgamerunner_1_1Dispatcher =
[
    [ "addUpdatable", "classgamerunner_1_1Dispatcher.html#a9d1e1cfe69e5576b60156957e38c9177", null ],
    [ "Awake", "classgamerunner_1_1Dispatcher.html#aa86c7cbf28ac92b9f83ad47e2517ab6d", null ],
    [ "Update", "classgamerunner_1_1Dispatcher.html#a91638eb85fe0844b65e651b6d1fa504a", null ],
    [ "_updatables", "classgamerunner_1_1Dispatcher.html#af0384e25a7bdb5fdc4b1f1759f966df9", null ]
];