var searchData=
[
  ['id_0',['Id',['../interfacegame_1_1logic_1_1EventQueue_1_1IEvent.html#a307c56730363fc273d2069f83257c5ae',1,'game.logic.EventQueue.IEvent.Id()'],['../classgame_1_1logic_1_1EventQueue_1_1SpawnTileEvent.html#aac9c4d2d5ce47ad89a969230ffd4f2c4',1,'game.logic.EventQueue.SpawnTileEvent.Id()'],['../classgame_1_1logic_1_1EventQueue_1_1UserLoginEvent.html#a94678786e1867516ee73660f297cdbe5',1,'game.logic.EventQueue.UserLoginEvent.Id()']]]
];
