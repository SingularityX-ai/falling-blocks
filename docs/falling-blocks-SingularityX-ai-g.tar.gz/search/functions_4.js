var searchData=
[
  ['gamerunner_0',['GameRunner',['../classGameRunner.html#a4c22840aa95ea81167ec398ca75afd08',1,'GameRunner']]],
  ['getservice_3c_20t_20_3e_1',['GetService&lt; T &gt;',['../classgame_1_1service_1_1ServiceLocator.html#ac8a69a906768092113681ed1e1d5dd6a',1,'game::service::ServiceLocator']]],
  ['gettile_2',['GetTile',['../classgame_1_1logic_1_1playfield_1_1PlayFieldViewModel.html#ac1c7a5c6b8858791a1bb5187198eca86',1,'game::logic::playfield::PlayFieldViewModel']]],
  ['getusername_3',['GetUserName',['../classnetwork_1_1user_1_1UserService.html#ac4ef94bbb341b2f32a63ca022042f29d',1,'network::user::UserService']]],
  ['gravityservice_4',['GravityService',['../classgame_1_1logic_1_1GravityService.html#aaaf0bd46468281bd895f3b679a1550c3',1,'game::logic::GravityService']]]
];
