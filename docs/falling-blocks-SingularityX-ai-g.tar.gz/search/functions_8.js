var searchData=
[
  ['personview_0',['PersonView',['../classdocumentation__evaluation_1_1person_1_1PersonView.html#ad1a27cd6bac46bc751d519de8dfa5bbb',1,'documentation_evaluation::person::PersonView']]],
  ['personviewmodel_1',['PersonViewModel',['../classdocumentation__evaluation_1_1person_1_1PersonViewModel.html#ae884c60f8eacf51e0bc0b817cde64628',1,'documentation_evaluation::person::PersonViewModel']]],
  ['placetile_2',['PlaceTile',['../classgame_1_1logic_1_1playfield_1_1PlayFieldViewModel.html#a846bdf145edb58386e62d434628431d4',1,'game::logic::playfield::PlayFieldViewModel']]],
  ['playfieldviewmodel_3',['PlayFieldViewModel',['../classgame_1_1logic_1_1playfield_1_1PlayFieldViewModel.html#abb9011aefc864999f47904f216af5188',1,'game::logic::playfield::PlayFieldViewModel']]]
];
