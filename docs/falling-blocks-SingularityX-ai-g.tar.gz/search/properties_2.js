var searchData=
[
  ['gravity_0',['Gravity',['../interfacegame_1_1logic_1_1IGravityStrategy.html#a0ecc8f43e706defbb23aac46034daf6b',1,'game.logic.IGravityStrategy.Gravity()'],['../classgame_1_1logic_1_1LevelBasedGravityStrategy.html#a99d30f8169e0002f4aa38aef4000b2f0',1,'game.logic.LevelBasedGravityStrategy.Gravity()'],['../classgame_1_1logic_1_1TimeBasedGravityStrategy.html#aecde7c795ae190b45ececb104e3744a5',1,'game.logic.TimeBasedGravityStrategy.Gravity()']]]
];
