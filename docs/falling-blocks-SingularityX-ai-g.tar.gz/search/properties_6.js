var searchData=
[
  ['source_0',['Source',['../interfacegame_1_1logic_1_1EventQueue_1_1IEvent.html#a49f2a7e9ecddd0d532af39973adac177',1,'game.logic.EventQueue.IEvent.Source()'],['../classgame_1_1logic_1_1EventQueue_1_1SpawnTileEvent.html#a60adbef29987d84667a869263dd1dd13',1,'game.logic.EventQueue.SpawnTileEvent.Source()'],['../classgame_1_1logic_1_1EventQueue_1_1UserLoginEvent.html#a5026e6c15a63262b7b0ea9288755bd8b',1,'game.logic.EventQueue.UserLoginEvent.Source()']]]
];
