var searchData=
[
  ['dequeue_0',['Dequeue',['../classgame_1_1logic_1_1EventQueue_1_1EventQueue.html#a66acb00d8ce084f3d0c88d588d8cb6ec',1,'game::logic::EventQueue::EventQueue']]],
  ['display_1',['Display',['../classdocumentation__evaluation_1_1person_1_1PersonView.html#a97df5690154ae85c6069220f2e70abb4',1,'documentation_evaluation::person::PersonView']]]
];
