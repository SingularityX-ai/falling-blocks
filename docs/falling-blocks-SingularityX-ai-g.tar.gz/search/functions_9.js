var searchData=
[
  ['registerservice_3c_20t_20_3e_0',['RegisterService&lt; T &gt;',['../classgame_1_1service_1_1ServiceLocator.html#a112fe2a38768eabfc637ec9c00a446ca',1,'game::service::ServiceLocator']]],
  ['resetlevel_1',['ResetLevel',['../classgame_1_1logic_1_1LevelBasedGravityStrategy.html#a6624c0cba3f5bd6ca5031e519f8e77b7',1,'game::logic::LevelBasedGravityStrategy']]]
];
