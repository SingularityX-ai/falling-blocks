var searchData=
[
  ['assemblyinfo_2ecs_0',['AssemblyInfo.cs',['../AssemblyInfo_8cs.html',1,'']]]
];
