var searchData=
[
  ['createhttprequest_0',['CreateHttpRequest',['../classnetwork_1_1HttpRequestFactory.html#a48959f4cca00a18a7bc61265851fb8f4',1,'network::HttpRequestFactory']]],
  ['createtileshapedelegate_1',['CreateTileShapeDelegate',['../classgame_1_1logic_1_1tilespawner_1_1TileSpawnerService.html#a2fcfd8729028ad973b1fa1a4969350e4',1,'game::logic::tilespawner::TileSpawnerService']]]
];
