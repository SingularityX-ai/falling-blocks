var searchData=
[
  ['gameinitialiser_0',['GameInitialiser',['../classGameInitialiser.html',1,'']]],
  ['gamerunner_1',['GameRunner',['../classGameRunner.html',1,'']]],
  ['gravityservice_2',['GravityService',['../classgame_1_1logic_1_1GravityService.html',1,'game::logic']]]
];
