var HttpRequest_8cs =
[
    [ "network.HttpGetRequest", "classnetwork_1_1HttpGetRequest.html", "classnetwork_1_1HttpGetRequest" ],
    [ "network.HttpPostRequest", "classnetwork_1_1HttpPostRequest.html", "classnetwork_1_1HttpPostRequest" ]
];