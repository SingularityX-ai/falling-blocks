var dir_452a23fe505bc52cdab608fbc8292f68 =
[
    [ "Dispatcher.cs", "Dispatcher_8cs.html", "Dispatcher_8cs" ],
    [ "GameRunner.cs", "GameRunner_8cs.html", "GameRunner_8cs" ],
    [ "IUpdatable.cs", "IUpdatable_8cs.html", "IUpdatable_8cs" ]
];