var namespaces_dup =
[
    [ "debugtools", "namespacedebugtools.html", "namespacedebugtools" ],
    [ "documentation_evaluation", "namespacedocumentation__evaluation.html", "namespacedocumentation__evaluation" ],
    [ "game", "namespacegame.html", "namespacegame" ],
    [ "gamerunner", "namespacegamerunner.html", "namespacegamerunner" ],
    [ "network", "namespacenetwork.html", "namespacenetwork" ]
];