var classdebugtools_1_1DebugReceiver =
[
    [ "Action", "classdebugtools_1_1DebugReceiver.html#ad644f8a097ae4a74950667f9fa8be94e", null ],
    [ "supportedCommands", "classdebugtools_1_1DebugReceiver.html#ace9c71792ad7306524f245f341a1a271", null ]
];