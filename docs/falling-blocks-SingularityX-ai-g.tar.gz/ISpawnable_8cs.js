var ISpawnable_8cs =
[
    [ "game.logic.tilespawner.ISpawnable", "interfacegame_1_1logic_1_1tilespawner_1_1ISpawnable.html", "interfacegame_1_1logic_1_1tilespawner_1_1ISpawnable" ]
];