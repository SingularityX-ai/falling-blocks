var namespacenetwork =
[
    [ "score", "namespacenetwork_1_1score.html", "namespacenetwork_1_1score" ],
    [ "user", "namespacenetwork_1_1user.html", "namespacenetwork_1_1user" ],
    [ "HttpGetRequest", "classnetwork_1_1HttpGetRequest.html", "classnetwork_1_1HttpGetRequest" ],
    [ "HttpPostRequest", "classnetwork_1_1HttpPostRequest.html", "classnetwork_1_1HttpPostRequest" ],
    [ "HttpRequestFactory", "classnetwork_1_1HttpRequestFactory.html", "classnetwork_1_1HttpRequestFactory" ],
    [ "IHttpRequest", "interfacenetwork_1_1IHttpRequest.html", "interfacenetwork_1_1IHttpRequest" ]
];