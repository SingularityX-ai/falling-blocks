var namespacegamerunner =
[
    [ "Dispatcher", "classgamerunner_1_1Dispatcher.html", "classgamerunner_1_1Dispatcher" ],
    [ "IUpdatable", "interfacegamerunner_1_1IUpdatable.html", "interfacegamerunner_1_1IUpdatable" ]
];