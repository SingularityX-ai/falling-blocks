var classgame_1_1logic_1_1tile_1_1TileViewModel =
[
    [ "TileViewModel", "classgame_1_1logic_1_1tile_1_1TileViewModel.html#a367d32bcd326c14f20931a3de74f7f90", null ],
    [ "_playFieldVM", "classgame_1_1logic_1_1tile_1_1TileViewModel.html#a942cd4412757fed87d7b86f193c93d00", null ],
    [ "_x", "classgame_1_1logic_1_1tile_1_1TileViewModel.html#aef029c8408e9b935db0b285edc021df4", null ],
    [ "_y", "classgame_1_1logic_1_1tile_1_1TileViewModel.html#ad79c24a526de9ab7dad8a4cd04beb47c", null ],
    [ "Color", "classgame_1_1logic_1_1tile_1_1TileViewModel.html#a3007c17fcc70b562d82714a0d2ac8025", null ],
    [ "X", "classgame_1_1logic_1_1tile_1_1TileViewModel.html#a2e8b1a87845fd6edd5fbb0267b1782d5", null ],
    [ "Y", "classgame_1_1logic_1_1tile_1_1TileViewModel.html#a8da1b8f04ebecdc4056daa9690dd3564", null ]
];