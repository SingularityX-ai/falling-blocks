var interfacegamerunner_1_1IUpdatable =
[
    [ "Update", "interfacegamerunner_1_1IUpdatable.html#a684cabd1d0eca2204271adcacf5b1505", null ]
];