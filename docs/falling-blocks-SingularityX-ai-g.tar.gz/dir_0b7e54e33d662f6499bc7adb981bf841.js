var dir_0b7e54e33d662f6499bc7adb981bf841 =
[
    [ ".NETFramework,Version=v4.7.AssemblyAttributes.cs", "_8NETFramework_00Version_0av4_87_8AssemblyAttributes_8cs.html", null ]
];